# Athlix Design System

Athlix is a training & performance tracking product for athletes — tagline **"Track. Recover. Perform."** It pairs a marketing/auth surface (Next.js, polished dark UI with a signature lime-green accent) with a deeper in-app dashboard (the "legacy app", a Vite bundle embedded via iframe at `/dashboard`) for logging workouts, monitoring recovery & readiness, and analyzing performance over time.

## Sources (attached)
- **Codebase:** `AthlixV2.1-1/` (local, mounted read-only)
  - Marketing + auth pages: `app/login`, `app/signup`, `app/onboarding`, `app/dashboard`, `app/reset-password`, `app/verify-email`
  - Global tokens: `app/globals.css`
  - Root layout: `app/layout.tsx` (loads `DM_Sans` + `Bebas_Neue` via `next/font/google`)
  - Embedded dashboard app: `public/legacy-app/` (prebuilt Vite bundle w/ its own tokens in `--bg-base`, `--accent`, muscle-group colors, readiness rings)
- **GitHub:** `gajeradhrumil38/Athlix_v2_1` — same project, used on demand
- **Exercise illustration library:** `AthlixV2.1-1/opentraining-exercises-master/` — ~280 PNG pose-pair exercise illustrations (Arnold press, bench press, bicep curls…). Generic fitness art, not brand-owned; useful as workout thumbnails.

## Products
1. **Athlix Web** — marketing & auth (Next.js, DM Sans). Dark, minimal, split-panel auth with grid pattern + lime glow blob. Covered in `ui_kits/web/`.
2. **Athlix App** — authenticated dashboard (Vite bundle, Inter). Deeper navy background, readiness rings, muscle-group coloring, workout logging. Covered in `ui_kits/app/`.

## Content Fundamentals
- **Voice:** Second-person, motivating but matter-of-fact. *"Track. Recover. Perform."* *"Start performing better."* *"Join athletes who track smarter."*
- **Tone:** Confident, gym-floor practical — no hype words like "unlock" or "revolutionize". Benefits stated plainly: *"Log workouts in seconds."* *"Monitor recovery & readiness."* *"Analyze performance over time."*
- **Casing:** Sentence case for UI labels ("Create account", "Sign in", "Forgot password?"). Uppercase reserved for the Bebas wordmark and for tiny section eyebrows (`.athlix-tiny` — 11px, 0.18em tracking, e.g. "OR CONTINUE WITH").
- **Person:** Talks TO the user in second person ("What do you train for?" "What's your main goal?" "A few quick preferences"). Never first-person plural for the brand except light warmth ("We'll tailor your experience around it.").
- **Errors:** Human, never technical. *"Incorrect email or password. Try again."* *"Connection issue. Please try again."* *"Too many attempts. Try again in 15 min."*
- **Success:** Short and celebratory. *"Welcome back!"* *"Account created."* *"Reset link sent!"*
- **Emoji:** Used sparingly inside onboarding sport pickers only (🏃 🚴 🏊 🏋️ ⚡ 🎯). Never in marketing, body copy, or buttons. Never decorative.
- **Numbers:** Plain digits, never spelled out. Units lowercase ("km", "mi", "kg", "lbs"). Ratings: "4.9★". Counts: "10,000+".
- **Stats chips** use a pill format: `10,000+ workouts logged` · `4.9★ avg rating` · `Free to start`.

## Visual Foundations
- **Palette:** Jet-black base (`#0a0a0a`) → dark surface (`#141414`) → input (`#1e1e1e`) → hairline (`#2a2a2a`). Text tops out at `#f0f0f0`. Accents are a single **lime** (`#C8FF00`) — never a rainbow, never a purple gradient. Status = lime green for success, `#ff4d4d` for error, `#ffd54f` for warn. The in-app dashboard shifts the base to a deeper navy (`#0a0c10` / `#121720`) and introduces dedicated muscle-group hues (chest pink, back sage, legs orange, shoulders lavender, core lime).
- **Type:** Two families. **Bebas Neue** (display-only, wordmark at 72px/52px, always lime, always uppercase). **DM Sans** (everything else — marketing + auth). The embedded dashboard uses **Inter** instead of DM Sans — same weight ladder, slightly more neutral. Sizes cluster at 11 / 12 / 13 / 14 / 15 / 22 / 24 / 52 / 72. Weights: 400, 500, 600 (buttons), 700.
- **Backgrounds:** Flat matte-black, not gradients. Auth split-panel adds a subtle 40px SVG grid at ~4% opacity plus a single 96×96-spacing lime blob blurred at 80px, ~5-6% opacity — that's it. No full-bleed photography in the frame (exercise PNGs live inside cards, not as backgrounds). No noise, no illustration.
- **Animation:** Minimal. 150ms `ease` on hovers/borders. Page fade-in (`animation: fadeIn 0.15s ease`). Framer Motion used for: (a) shake on form error (x: [0,-8,8,-6,6,0], 320ms ease-out), (b) banner slide-in (y:-6 → 0), (c) forgot-password panel height auto collapse. Onboarding step dots animate width 8→24px. No bouncy springs, no parallax.
- **Hover:** Accent buttons darken to `#b0e000`. Neutral buttons → `text: #f0f0f0`. OAuth buttons → bg `#f5f5f5`. Links underline with `underline-offset-4`.
- **Press/disabled:** `opacity: 0.45` + `cursor: not-allowed`. No shrink.
- **Focus:** 3px outer glow `rgba(200,255,0,0.12)` + border swap to `#C8FF00`. Dashboard uses `outline: 2px solid var(--accent)` with `outline-offset: 2px`.
- **Borders:** 1px, `#2a2a2a` (web) / `#1e2638` (app). Selected state = `#C8FF00` border + lime tinted bg (`rgba(200,255,0,0.06–0.08)`).
- **Radii:** 8px (inputs, buttons, chips), 12px cards, 16–24px modal/bottom-sheet surfaces, full-round for pills/stat chips/step dots.
- **Cards:** Surface `#141414` or `#1a1a1a`, 1px `#2a2a2a` border, 12–16px radius, no drop shadow by default — depth comes from layering tones, not shadow. Dashboard cards use `linear-gradient(180deg,#171717 0%,#121212 100%)` subtle tone shifts.
- **Transparency & blur:** Used for modal overlays (`bg-black/60`), sticky nav (`bg-[var(--bg-base)]/78` + backdrop-blur), and accent chips (`bg-[#C8FF00]/8`). Never on primary surfaces.
- **Imagery vibe:** Cool, desaturated, high-contrast on black. The brand doesn't ship photography in the codebase; exercise illustrations are flat 2-frame PNG pose pairs — keep them on dark cards.
- **Layout rules:** 400–480px max form columns, 860–920px max content widths. Split 50/50 on auth at `md:`. Mobile drops the left panel entirely and centers a 52px wordmark.
- **Signature motifs:** (1) The lime wordmark. (2) The 40×40 faint grid SVG pattern at 4% opacity. (3) The lime blur blob in a corner. (4) Short vertical lime bars (`h-5 w-0.5`) as feature-list bullets instead of dots.

## Iconography
- **Library:** `lucide-react` — consistent stroke-based 1.5px icons. Sizes: `h-3.5 w-3.5` in helper text, `h-4 w-4` default inline, `h-5 w-5` in buttons, `h-6 w-6` and up for empty states.
- **Icons actually used in code:** `CheckCircle2`, `Eye`/`EyeOff`, `Loader2` (spinner, `animate-spin`), `X` (dismiss), `ChevronLeft`. The app iframe adds more (bar chart, flame, dumbbell, calendar) — all Lucide.
- **CDN:** We load Lucide via `unpkg.com/lucide@latest` in preview files and UI kits (no substitution).
- **Logo mark:** A single glyph `A` in Bebas Neue inside an 8px-rounded black tile (`assets/athlix-favicon.svg`). Full wordmark in `assets/athlix-wordmark.svg`.
- **Emoji:** Only in the onboarding sport picker (🏃 🚴 🏊 🏋️ ⚡ 🎯). Nowhere else.
- **Unicode marks:** One intentional glyph —  (Apple logo) on the "Continue with Apple" button when Safari is detected. Star ★ appears in the `4.9★` stat chip.
- **SVGs:** Google "G" logo inline (Google's official 4-color mark) and a 40×40 tile grid background pattern. Those are authored inline; all other pictorial icons come from Lucide.

## Index
- `README.md` — this file
- `colors_and_type.css` — all CSS vars, fonts, type scale, semantic roles
- `SKILL.md` — skill entrypoint for agent use
- `assets/` — logo, favicon, wordmark
- `preview/` — design-system review cards (colors, type, components, brand)
- `ui_kits/web/` — marketing + auth recreation (Next.js-style landing + split-panel login/signup/onboarding)
- `ui_kits/app/` — in-app dashboard recreation (readiness rings, workout logging)

## Notes on substitutions
- Fonts are loaded from Google Fonts at runtime (same families Next.js uses in the source — `DM_Sans`, `Bebas_Neue`, `Inter`). No `.ttf` files bundled; if you need fully offline assets, add them to `fonts/` and flag for review.
- Lucide icons load from CDN (`unpkg.com/lucide@latest`) — this matches the `lucide-react` usage in the source.
- No real photography is shipped with the codebase, so no photography is shipped here. If you need hero imagery, request it.
