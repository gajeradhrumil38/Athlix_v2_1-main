/* global React */
const { useState, useMemo } = React;

const ACC = '#C8FF00';
const BG = '#0a0a0a';
const SURF = '#141414';
const BORDER = '#2a2a2a';
const TXT = '#f0f0f0';
const MUTE = '#888';
const DIM = '#666';

// 12 weeks of synthetic "bench press 1RM" data with noise + trend
const WEEKS = Array.from({length:12},(_,i)=>{
  const base = 80 + i*1.6 + Math.sin(i*.8)*3;
  return { w:i+1, min:base-4-Math.random()*2, med:base, max:base+3+Math.random()*2, sessions: 3+(i%3) };
});

const WEIGHT = [82,83,82,84,85,84,86,87,86,88,89,90,89,91,92,91,93,94,93,95,96,95,97,98];
const WEIGHT_LABELS = Array.from({length:24},(_,i)=>`W${Math.floor(i/2)+1}`);

// === Opt 1: ABR (Area + Band + Range) — median line with min/max band ===
function ABRChart(){
  const W=640,H=260,PL=44,PR=20,PT=20,PB=36;
  const iw=W-PL-PR, ih=H-PT-PB;
  const xs=(i)=>PL+(i/(WEEKS.length-1))*iw;
  const ys=(v)=>PT+ih-((v-70)/35)*ih;
  const bandTop=WEEKS.map((d,i)=>`${xs(i)},${ys(d.max)}`).join(' ');
  const bandBot=WEEKS.map((d,i)=>`${xs(i)},${ys(d.min)}`).reverse().join(' ');
  const line=WEEKS.map((d,i)=>`${i?'L':'M'}${xs(i)} ${ys(d.med)}`).join(' ');
  const latest=WEEKS[WEEKS.length-1];
  return (
    <div style={card}>
      <div style={head}>
        <div>
          <div style={eyebrow}>Bench press · est. 1RM</div>
          <div style={{display:'flex',alignItems:'baseline',gap:10,marginTop:6}}>
            <div style={{font:"600 36px/1 'DM Sans'",color:TXT}}>{latest.med.toFixed(1)}<span style={{color:MUTE,fontSize:18,marginLeft:4}}>kg</span></div>
            <div style={{color:ACC,font:"500 13px/1 'DM Sans'"}}>▲ 11.2% vs W1</div>
          </div>
        </div>
        <div style={tabs}>{['4W','12W','6M','1Y'].map((t,i)=>(<div key={t} style={{...tab,...(i===1?tabOn:{})}}>{t}</div>))}</div>
      </div>
      <svg viewBox={`0 0 ${W} ${H}`} style={{width:'100%',height:260,display:'block'}}>
        <defs>
          <linearGradient id="abr" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={ACC} stopOpacity=".22"/>
            <stop offset="100%" stopColor={ACC} stopOpacity="0"/>
          </linearGradient>
        </defs>
        {[0,.25,.5,.75,1].map(p=>(<line key={p} x1={PL} x2={W-PR} y1={PT+p*ih} y2={PT+p*ih} stroke="#1e1e1e" strokeWidth="1"/>))}
        {[75,85,95,105].map(v=>(<text key={v} x={PL-8} y={ys(v)+3} fill={DIM} fontSize="10" textAnchor="end" fontFamily="DM Sans">{v}</text>))}
        <polygon points={`${bandTop} ${bandBot}`} fill="url(#abr)" stroke="none"/>
        <polyline points={WEEKS.map((d,i)=>`${xs(i)},${ys(d.max)}`).join(' ')} fill="none" stroke={ACC} strokeOpacity=".35" strokeWidth="1" strokeDasharray="2 3"/>
        <polyline points={WEEKS.map((d,i)=>`${xs(i)},${ys(d.min)}`).join(' ')} fill="none" stroke={ACC} strokeOpacity=".35" strokeWidth="1" strokeDasharray="2 3"/>
        <path d={line} fill="none" stroke={ACC} strokeWidth="2.2" strokeLinecap="round"/>
        {WEEKS.map((d,i)=>(<circle key={i} cx={xs(i)} cy={ys(d.med)} r={i===WEEKS.length-1?4.5:2.5} fill={i===WEEKS.length-1?ACC:'#0a0a0a'} stroke={ACC} strokeWidth={i===WEEKS.length-1?0:1.5}/>))}
        {WEEKS.filter((_,i)=>i%3===0).map((d,i)=>(<text key={i} x={xs(WEEKS.indexOf(d))} y={H-14} fill={DIM} fontSize="10" textAnchor="middle" fontFamily="DM Sans">W{d.w}</text>))}
        <g transform={`translate(${xs(WEEKS.length-1)-76} ${ys(latest.med)-46})`}>
          <rect width="76" height="34" rx="6" fill="#1a1a1a" stroke={BORDER}/>
          <text x="10" y="14" fill={MUTE} fontSize="9" fontFamily="DM Sans">RANGE</text>
          <text x="10" y="27" fill={TXT} fontSize="12" fontWeight="600" fontFamily="DM Sans">{latest.min.toFixed(0)}–{latest.max.toFixed(0)}kg</text>
        </g>
      </svg>
      <div style={legend}>
        <LItem c={ACC} t="Median 1RM"/>
        <LItem c={ACC} alpha={.4} dash t="Set range (min–max)"/>
        <LItem c={ACC} alpha={.22} swatch t="Band"/>
      </div>
    </div>
  );
}

// === Opt 2: Horizontal bars + per-row sparklines (mono + lime) ===
function MountainChart(){
  const groups=[
    {k:'Chest', d:[14,16,15,18,20,22]},
    {k:'Legs',  d:[9,11,10,13,13,15]},
    {k:'Back',  d:[8,9,10,11,12,12]},
    {k:'Core',  d:[3,4,5,6,8,9]},
  ];
  const maxV=Math.max(...groups.map(g=>g.d[g.d.length-1]));
  const total=groups.reduce((a,g)=>a+g.d[g.d.length-1],0);
  const lastWeekTotal=groups.reduce((a,g)=>a+g.d[g.d.length-2],0);
  const delta=total-lastWeekTotal;
  return (
    <div style={card}>
      <div style={head}>
        <div>
          <div style={eyebrow}>Weekly volume · by muscle group</div>
          <div style={{display:'flex',alignItems:'baseline',gap:10,marginTop:6}}>
            <div style={{font:"600 36px/1 'DM Sans'",color:TXT}}>{total}<span style={{color:MUTE,fontSize:18,marginLeft:4}}>sets this week</span></div>
            <div style={{color:ACC,font:"500 13px/1 'DM Sans'"}}>{delta>=0?'▲':'▼'} {Math.abs(delta)} vs last week</div>
          </div>
        </div>
        <div style={tabs}>{['6W','12W','6M','1Y'].map((t,i)=>(<div key={t} style={{...tab,...(i===0?tabOn:{})}}>{t}</div>))}</div>
      </div>
      <div style={{padding:'8px 22px 18px',display:'flex',flexDirection:'column',gap:2}}>
        <div style={{display:'grid',gridTemplateColumns:'60px 1fr 120px 44px',alignItems:'center',padding:'6px 0',color:DIM,font:"500 10px/1 'DM Sans'",letterSpacing:'.14em',textTransform:'uppercase',borderBottom:`1px solid ${BORDER}`}}>
          <div>Group</div><div>Volume (sets)</div><div>6-week trend</div><div style={{textAlign:'right'}}>Δ</div>
        </div>
        {groups.map((g,gi)=>{
          const v=g.d[g.d.length-1];
          const pct=v/maxV;
          const prev=g.d[g.d.length-2];
          const d=v-prev;
          const isTop=gi===0;
          // sparkline
          const sw=108,sh=26;
          const sMin=Math.min(...g.d), sMax=Math.max(...g.d);
          const sx=(i)=>(i/(g.d.length-1))*sw;
          const sy=(val)=>sh-((val-sMin)/(sMax-sMin||1))*sh;
          const path=g.d.map((val,i)=>`${i?'L':'M'}${sx(i)} ${sy(val)}`).join(' ');
          const areaPath=`${path} L ${sw} ${sh} L 0 ${sh} Z`;
          return (
            <div key={g.k} style={{display:'grid',gridTemplateColumns:'60px 1fr 120px 44px',alignItems:'center',padding:'14px 0',borderBottom:gi<groups.length-1?`1px solid #1e1e1e`:'none',gap:12}}>
              <div style={{color:isTop?TXT:'#c8c8c8',font:"600 13px/1 'DM Sans'"}}>{g.k}</div>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <div style={{flex:1,height:8,background:'#1a1a1a',borderRadius:4,overflow:'hidden',position:'relative'}}>
                  <div style={{width:`${pct*100}%`,height:'100%',background:isTop?ACC:'#e6e6e6',opacity:isTop?1:.7,transition:'.3s'}}/>
                </div>
                <div style={{color:TXT,font:"600 14px/1 'DM Sans'",minWidth:22,textAlign:'right'}}>{v}</div>
              </div>
              <svg viewBox={`0 0 ${sw} ${sh}`} style={{width:sw,height:sh,display:'block'}}>
                <path d={areaPath} fill={isTop?ACC:'#888'} fillOpacity={isTop?.18:.08}/>
                <path d={path} fill="none" stroke={isTop?ACC:'#888'} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx={sx(g.d.length-1)} cy={sy(v)} r="2.5" fill={isTop?ACC:'#c8c8c8'}/>
              </svg>
              <div style={{textAlign:'right',color:d>=0?ACC:'#ff7a59',font:"500 12px/1 'DM Sans'"}}>{d>=0?'+':''}{d}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// === Opt 3: Sparkline barbell — bar ladder + trend sparkline ===
function LadderChart(){
  const max=Math.max(...WEIGHT);
  const min=Math.min(...WEIGHT);
  return (
    <div style={card}>
      <div style={head}>
        <div>
          <div style={eyebrow}>Body weight · 24 weighs</div>
          <div style={{display:'flex',alignItems:'baseline',gap:10,marginTop:6}}>
            <div style={{font:"600 36px/1 'DM Sans'",color:TXT}}>{WEIGHT[WEIGHT.length-1]}<span style={{color:MUTE,fontSize:18,marginLeft:4}}>kg</span></div>
            <div style={{color:'#ff7a59',font:"500 13px/1 'DM Sans'"}}>+{WEIGHT[WEIGHT.length-1]-WEIGHT[0]} kg · 12W</div>
          </div>
        </div>
        <div style={tabs}>{['D','W','M','Y'].map((t,i)=>(<div key={t} style={{...tab,...(i===1?tabOn:{})}}>{t}</div>))}</div>
      </div>
      <div style={{padding:'8px 20px 6px',display:'flex',alignItems:'flex-end',gap:4,height:140}}>
        {WEIGHT.map((v,i)=>{
          const h=((v-min+1)/(max-min+2))*100;
          const hot=i===WEIGHT.length-1;
          return (<div key={i} title={`${v}kg`} style={{flex:1,height:`${h}%`,background:hot?ACC:'#2a2a2a',borderRadius:2,minHeight:4,transition:'.2s'}}/>);
        })}
      </div>
      <div style={{display:'flex',justifyContent:'space-between',padding:'0 20px 14px',color:DIM,font:"500 11px/1 'DM Sans'",letterSpacing:'.08em'}}>
        <span>W1</span><span>W6</span><span>W12</span>
      </div>
      <div style={{borderTop:`1px solid ${BORDER}`,display:'grid',gridTemplateColumns:'repeat(3,1fr)'}}>
        {[{l:'Low',v:`${min} kg`},{l:'Avg',v:`${(WEIGHT.reduce((a,b)=>a+b,0)/WEIGHT.length).toFixed(1)} kg`},{l:'High',v:`${max} kg`}].map((s,i)=>(
          <div key={s.l} style={{padding:'14px 20px',borderRight:i<2?`1px solid ${BORDER}`:'none'}}>
            <div style={{color:MUTE,font:"500 11px/1 'DM Sans'",textTransform:'uppercase',letterSpacing:'.12em'}}>{s.l}</div>
            <div style={{color:TXT,font:"600 18px/1 'DM Sans'",marginTop:6}}>{s.v}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ========== shared bits ==========
const card={background:SURF,border:`1px solid ${BORDER}`,borderRadius:8,overflow:'hidden',width:720};
const head={padding:'20px 22px 12px',display:'flex',alignItems:'flex-start',justifyContent:'space-between',gap:12};
const eyebrow={color:MUTE,font:"500 11px/1 'DM Sans'",textTransform:'uppercase',letterSpacing:'.14em'};
const tabs={display:'flex',gap:4,background:'#1a1a1a',border:`1px solid ${BORDER}`,borderRadius:8,padding:3};
const tab={padding:'6px 12px',font:"500 12px/1 'DM Sans'",color:MUTE,borderRadius:6,cursor:'pointer'};
const tabOn={background:'#2a2a2a',color:TXT};
const legend={display:'flex',gap:18,padding:'12px 22px 20px',borderTop:`1px solid ${BORDER}`};
function LItem({c,t,alpha=1,dash,swatch}){
  return (<div style={{display:'flex',alignItems:'center',gap:8,color:MUTE,font:"500 12px/1 'DM Sans'"}}>
    {swatch
      ? <div style={{width:14,height:8,background:c,opacity:alpha,borderRadius:2}}/>
      : <div style={{width:16,height:2,background:c,opacity:alpha,borderRadius:2,...(dash?{background:`repeating-linear-gradient(90deg,${c} 0 3px,transparent 3px 6px)`}:{})}}/>}
    {t}
  </div>);
}

// ========== page ==========
function ProgressPage(){
  return (
    <div style={{minHeight:'100vh',background:BG,color:TXT,fontFamily:"'DM Sans',system-ui,sans-serif",padding:'40px 28px 80px'}}>
      <div style={{maxWidth:1120,margin:'0 auto'}}>
        <div style={{font:"400 42px/1 'Victory Striker','Bebas Neue',sans-serif",color:ACC,letterSpacing:'.02em'}}>PROGRESS</div>
        <div style={{color:MUTE,font:"400 15px/1.5 'DM Sans'",marginTop:8,marginBottom:36,maxWidth:560}}>Three chart patterns for tracking long-term performance. Same data model, different visual idioms — pick whichever reads cleanest for each metric.</div>
        <div style={{display:'flex',flexDirection:'column',gap:28}}>
          <Labeled n="01" title="ABR · Area + Band + Range" sub="Best for single metrics with variance — 1RM estimates, HRV, readiness. Median line sits on a translucent min/max band."><ABRChart/></Labeled>
          <Labeled n="02" title="Rows · Volume + trend" sub="Best for answering 'what am I training most, and is it going up?' — one row per muscle group with a volume bar and a 6-week sparkline. Scales to any number of categories."><MountainChart/></Labeled>
          <Labeled n="03" title="Ladder · Bars + summary" sub="Best for dense, high-frequency logs — daily weigh-ins, RPE, sleep. Latest bar lights up; low/avg/high docked below."><LadderChart/></Labeled>
        </div>
      </div>
    </div>
  );
}
function Labeled({n,title,sub,children}){
  return (<div style={{display:'grid',gridTemplateColumns:'200px 1fr',gap:40,alignItems:'flex-start'}}>
    <div>
      <div style={{color:DIM,font:"500 11px/1 'DM Sans'",letterSpacing:'.18em'}}>OPTION {n}</div>
      <div style={{color:TXT,font:"600 18px/1.3 'DM Sans'",marginTop:10}}>{title}</div>
      <div style={{color:MUTE,font:"400 13px/1.5 'DM Sans'",marginTop:8}}>{sub}</div>
    </div>
    <div>{children}</div>
  </div>);
}
ReactDOM.createRoot(document.getElementById('root')).render(<ProgressPage/>);
