# Athlix Web UI Kit — Profile Page

A professional, minimal user profile/settings page with a sporty feel, built from the Athlix brand system.

## What's here
- `index.html` — entry point (loads React + the profile component)
- `profile.jsx` — full profile page: topbar, athlete hero, performance stat strip, account form, training preferences, notifications, right rail (readiness ring, connected devices, danger zone)

## Design notes
- Strict Athlix palette: `#0a0a0a` base, `#141414` cards, `#C8FF00` lime accent, `#2a2a2a` hairlines.
- Bebas Neue for the wordmark and hero letter only; DM Sans for all body copy.
- Sporty cues stay quiet: the lime accent bar under each stat, the circular readiness ring, a single lime blob behind the hero monogram, sport-pill selectors with emoji.
- No gradient backgrounds, no illustration, no drop shadows — depth comes from tone layering, per the brand.

## Register
The `index.html` is registered as the "Profile Page" asset at 1200×900.
