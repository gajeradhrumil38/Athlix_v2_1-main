/* global React */
const { useState, useEffect, useRef } = React;

const ACC = '#C8FF00';
const BG  = '#0a0a0a';
const S1  = '#141414';
const S2  = '#1a1a1a';
const BD  = '#2a2a2a';
const TXT = '#f0f0f0';
const MUT = '#888';
const DIM = '#555';

const pad = n => String(n).padStart(2,'0');
const todayStr = () => new Date().toISOString().slice(0,10);
const fmtDate = d => {
  const today = new Date(); today.setHours(0,0,0,0);
  const t = new Date(d+'T00:00:00'); t.setHours(0,0,0,0);
  const diff = Math.round((today-t)/(1000*60*60*24));
  if(diff===0) return 'Today';
  if(diff===1) return 'Yesterday';
  return new Date(d+'T00:00:00').toLocaleDateString('en-GB',{day:'numeric',month:'short'});
};

const EXERCISE_LIST = [
  {name:'Stairmaster',cat:'Cardio'},
  {name:'Bench Press',cat:'Chest'},
  {name:'Squat',cat:'Legs'},
  {name:'Deadlift',cat:'Back'},
  {name:'Pull-ups',cat:'Back'},
  {name:'Running',cat:'Cardio'},
  {name:'Cycling',cat:'Cardio'},
  {name:'Shoulder Press',cat:'Shoulders'},
  {name:'Bicep Curl',cat:'Biceps'},
  {name:'Plank',cat:'Core'},
];

const makeExercise = (name,cat) => ({name,cat,sets:[{min:20,sec:0,done:false}]});

/* ── timer ── */
function useTimer(){
  const [running,setRunning]=useState(false);
  const [secs,setSecs]=useState(0);
  const ref=useRef(null);
  useEffect(()=>{
    if(running){ref.current=setInterval(()=>setSecs(s=>s+1),1000);}
    else clearInterval(ref.current);
    return()=>clearInterval(ref.current);
  },[running]);
  return{running,secs,toggle:()=>setRunning(r=>!r),reset:()=>{setSecs(0);setRunning(false);}};
}

/* ── date chip ── */
function DateChip({date,onChange}){
  const inp=useRef();
  return(
    <button onClick={()=>inp.current.showPicker?inp.current.showPicker():inp.current.click()}
      style={{display:'flex',alignItems:'center',gap:5,height:30,padding:'0 10px',border:`1px solid ${BD}`,borderRadius:8,background:S2,color:MUT,font:"500 12px/1 'DM Sans'",cursor:'pointer',position:'relative'}}>
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke={MUT} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
      {fmtDate(date)}
      <input ref={inp} type="date" value={date} max={todayStr()} onChange={e=>onChange(e.target.value)}
        style={{position:'absolute',opacity:0,pointerEvents:'none',width:1,height:1}}/>
    </button>
  );
}

/* ── stepper ── */
function Stepper({label,value,onChange,min=0,max=99}){
  const press=d=>onChange(Math.max(min,Math.min(max,value+d)));
  return(
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:8,width:'100%'}}>
      <div style={{color:MUT,font:"500 10px/1 'DM Sans'",letterSpacing:'.14em',textTransform:'uppercase'}}>{label}</div>
      <div style={{display:'flex',alignItems:'center',width:'100%',gap:8}}>
        <button onClick={()=>press(-1)} style={stepBtn}>−</button>
        <div style={{font:"700 40px/1 'DM Sans'",color:TXT,textAlign:'center',flex:1}}>{pad(value)}</div>
        <button onClick={()=>press(+1)} style={stepBtn}>+</button>
      </div>
    </div>
  );
}
const stepBtn={width:40,height:40,border:`1px solid ${BD}`,borderRadius:8,background:'#222',color:TXT,fontSize:20,fontWeight:300,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',flexShrink:0};

/* ── set card ── */
function SetCard({idx,done,min,sec,onMin,onSec,onToggle}){
  return(
    <div style={{background:done?'rgba(200,255,0,.04)':S1,border:`1px solid ${done?'rgba(200,255,0,.25)':BD}`,borderRadius:8,padding:'14px 16px'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:14}}>
        <div style={{color:done?ACC:MUT,font:"700 11px/1 'DM Sans'",letterSpacing:'.1em'}}>SET {idx+1}</div>
        <button onClick={onToggle} style={{width:36,height:36,borderRadius:8,background:done?ACC:S2,border:`1px solid ${done?'transparent':BD}`,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke={done?'#000':MUT} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
        </button>
      </div>
      <div style={{display:'flex',gap:1,background:BD,borderRadius:8,overflow:'hidden'}}>
        <div style={{flex:1,background:S2,padding:'16px 12px',minWidth:0}}><Stepper label="MIN" value={min} onChange={onMin}/></div>
        <div style={{flex:1,background:S2,padding:'16px 12px',minWidth:0}}><Stepper label="SEC" value={sec} onChange={onSec} max={59}/></div>
      </div>
    </div>
  );
}

/* ── exercise picker sheet ── */
function ExercisePicker({onAdd,onClose}){
  const [q,setQ]=useState('');
  const filtered=EXERCISE_LIST.filter(e=>e.name.toLowerCase().includes(q.toLowerCase()));
  return(
    <div style={{position:'absolute',inset:0,background:'rgba(0,0,0,.75)',zIndex:50,display:'flex',flexDirection:'column',justifyContent:'flex-end'}} onClick={e=>{if(e.target===e.currentTarget)onClose();}}>
      <div style={{background:S1,borderRadius:'16px 16px 0 0',padding:'20px 16px 24px',border:`1px solid ${BD}`,borderBottom:'none',maxHeight:'75%',display:'flex',flexDirection:'column',gap:12}}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
          <div style={{font:"600 15px/1 'DM Sans'",color:TXT}}>Add Exercise</div>
          <button onClick={onClose} style={{width:30,height:30,borderRadius:8,background:S2,border:`1px solid ${BD}`,color:MUT,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer',fontSize:18,lineHeight:1}}>×</button>
        </div>
        {/* search */}
        <div style={{position:'relative'}}>
          <svg style={{position:'absolute',left:10,top:'50%',transform:'translateY(-50%)'}} width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={DIM} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search exercises…"
            style={{width:'100%',height:38,padding:'0 12px 0 30px',background:S2,border:`1px solid ${BD}`,borderRadius:8,color:TXT,font:"400 13px/1 'DM Sans'",outline:'none'}}/>
        </div>
        {/* list */}
        <div style={{overflowY:'auto',display:'flex',flexDirection:'column',gap:2}}>
          {filtered.map(e=>(
            <button key={e.name} onClick={()=>{onAdd(e.name,e.cat);onClose();}}
              style={{height:46,padding:'0 14px',background:S2,border:`1px solid ${BD}`,borderRadius:8,color:TXT,font:"500 13px/1 'DM Sans'",textAlign:'left',cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
              <span>{e.name}</span>
              <span style={{color:DIM,font:"400 11px/1 'DM Sans'",textTransform:'uppercase',letterSpacing:'.1em'}}>{e.cat}</span>
            </button>
          ))}
          {filtered.length===0&&<div style={{color:MUT,font:"400 13px/1 'DM Sans'",padding:'12px 0',textAlign:'center'}}>No results</div>}
        </div>
      </div>
    </div>
  );
}

/* ── exercise row (in list) ── */
function ExerciseRow({ex,active,onSelect}){
  const done=ex.sets.filter(s=>s.done).length;
  return(
    <button onClick={onSelect} style={{
      display:'flex',alignItems:'center',gap:12,
      padding:'12px 16px',background:active?'rgba(200,255,0,.04)':S1,
      border:`1px solid ${active?'rgba(200,255,0,.2)':BD}`,
      borderRadius:8,textAlign:'left',cursor:'pointer',width:'100%',
    }}>
      <div style={{width:36,height:36,borderRadius:8,background:active?'rgba(200,255,0,.1)':S2,border:`1px solid ${active?'rgba(200,255,0,.2)':BD}`,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0}}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={active?ACC:MUT} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z"/><path d="m2.5 21.5 1.4-1.4"/><path d="m20.1 3.9 1.4-1.4"/><path d="M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z"/></svg>
      </div>
      <div style={{flex:1,minWidth:0}}>
        <div style={{font:`${active?600:500} 13px/1 'DM Sans'`,color:active?TXT:MUT,marginBottom:3}}>{ex.name}</div>
        <div style={{font:"400 11px/1 'DM Sans'",color:DIM,letterSpacing:'.08em',textTransform:'uppercase'}}>{ex.cat} · {ex.sets.length} set{ex.sets.length!==1?'s':''}</div>
      </div>
      {done>0&&<div style={{height:20,padding:'0 7px',borderRadius:4,background:'rgba(200,255,0,.1)',border:'1px solid rgba(200,255,0,.2)',color:ACC,font:"600 10px/20px 'DM Sans'"}}>{done}/{ex.sets.length}</div>}
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={DIM} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
    </button>
  );
}

/* ── empty state ── */
function EmptyState({onAdd}){
  return(
    <div style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',gap:16,padding:'40px 24px'}}>
      <div style={{width:56,height:56,borderRadius:12,background:S1,border:`1px solid ${BD}`,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke={DIM} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M17.596 12.768a2 2 0 1 0 2.829-2.829l-1.768-1.767a2 2 0 0 0 2.828-2.829l-2.828-2.828a2 2 0 0 0-2.829 2.828l-1.767-1.768a2 2 0 1 0-2.829 2.829z"/><path d="m2.5 21.5 1.4-1.4"/><path d="m20.1 3.9 1.4-1.4"/><path d="M5.343 21.485a2 2 0 1 0 2.829-2.828l1.767 1.768a2 2 0 1 0 2.829-2.829l-6.364-6.364a2 2 0 1 0-2.829 2.829l1.768 1.767a2 2 0 0 0-2.828 2.829z"/></svg>
      </div>
      <div style={{textAlign:'center'}}>
        <div style={{font:"600 15px/1 'DM Sans'",color:TXT,marginBottom:6}}>No exercises yet</div>
        <div style={{font:"400 13px/1.5 'DM Sans'",color:MUT}}>Add your first exercise to start tracking.</div>
      </div>
      <button onClick={onAdd} style={{height:46,padding:'0 28px',background:ACC,color:'#000',border:'none',borderRadius:8,font:"700 14px/1 'DM Sans'",cursor:'pointer',display:'flex',alignItems:'center',gap:6}}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#000" strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
        Add Exercise
      </button>
    </div>
  );
}

/* ── main ── */
function WorkoutScreen(){
  const [date,setDate]=useState(todayStr());
  const timer=useTimer();
  const [exercises,setExercises]=useState([]);
  const [cur,setCur]=useState(null); // null = list view
  const [picking,setPicking]=useState(false);
  const isPast=fmtDate(date)!=='Today';

  const addExercise=(name,cat)=>{
    const next=[...exercises,makeExercise(name,cat)];
    setExercises(next);
    setCur(next.length-1);
  };
  const updEx=(i,fn)=>setExercises(s=>s.map((x,j)=>j===i?fn(x):x));
  const addSet=()=>updEx(cur,x=>({...x,sets:[...x.sets,{min:20,sec:0,done:false}]}));
  const updateSet=(si,f,v)=>updEx(cur,x=>({...x,sets:x.sets.map((s,j)=>j===si?{...s,[f]:v}:s)}));
  const toggleSet=si=>updEx(cur,x=>({...x,sets:x.sets.map((s,j)=>j===si?{...s,done:!s.done}:s)}));

  const totalDone=exercises.reduce((a,x)=>a+x.sets.filter(s=>s.done).length,0);
  const totalSets=exercises.reduce((a,x)=>a+x.sets.length,0);
  const ex=cur!==null?exercises[cur]:null;

  return(
    <div style={{height:'100%',background:BG,color:TXT,fontFamily:"'DM Sans',system-ui,sans-serif",display:'flex',flexDirection:'column',WebkitFontSmoothing:'antialiased',position:'relative',overflowY:'auto'}}>

      {/* NAV */}
      <div style={{padding:'10px 16px',display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
        {cur!==null
          ? <button onClick={()=>setCur(null)} style={navBtn}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={TXT} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
              <span style={{fontSize:13,fontWeight:500}}>All</span>
            </button>
          : <button style={navBtn}>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={TXT} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="15 18 9 12 15 6"/></svg>
              <span style={{fontSize:13,fontWeight:500}}>Back</span>
            </button>
        }
        <div style={{flex:1,textAlign:'center',minWidth:0}}>
          <div style={{font:"600 13px/1 'DM Sans'",color:TXT}}>Evening Workout</div>
          <div style={{font:"400 11px/1 'DM Sans'",color:MUT,marginTop:2}}>{exercises.length} exercise{exercises.length!==1?'s':''}</div>
        </div>
        <DateChip date={date} onChange={d=>{setDate(d);timer.reset();}}/>
      </div>

      {/* TIMER BAR — always visible */}
      {exercises.length>0&&(
        <div style={{padding:'0 16px 10px',display:'flex',alignItems:'center',gap:10,flexShrink:0}}>
          <div style={{font:"600 18px/1 'DM Sans'",color:TXT,fontVariantNumeric:'tabular-nums'}}>
            {pad(Math.floor(timer.secs/60))}:{pad(timer.secs%60)}
          </div>
          <button onClick={timer.toggle} style={{width:32,height:32,borderRadius:8,background:timer.running?ACC:S2,border:`1px solid ${timer.running?'transparent':BD}`,display:'flex',alignItems:'center',justifyContent:'center',cursor:'pointer'}}>
            {timer.running
              ?<svg width="11" height="11" viewBox="0 0 24 24" fill="#000"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
              :<svg width="11" height="11" viewBox="0 0 24 24" fill={ACC}><polygon points="5 3 19 12 5 21 5 3"/></svg>}
          </button>
          <div style={{width:1,height:14,background:BD}}/>
          <div style={{font:"500 12px/1 'DM Sans'",color:MUT}}>{totalDone}/{totalSets} sets done</div>
          {isPast&&<div style={{marginLeft:'auto',height:18,padding:'0 6px',borderRadius:4,background:'rgba(200,255,0,.08)',border:'1px solid rgba(200,255,0,.2)',color:ACC,font:"500 9px/18px 'DM Sans'",letterSpacing:'.1em'}}>PAST</div>}
        </div>
      )}

      <div style={{height:1,background:BD,margin:'0 16px',flexShrink:0}}/>

      {/* BODY */}
      {cur===null?(
        /* ── EXERCISE LIST VIEW ── */
        exercises.length===0
          ? <EmptyState onAdd={()=>setPicking(true)}/>
          : <div style={{padding:'12px 16px',display:'flex',flexDirection:'column',gap:8,flex:1}}>
              {exercises.map((ex,i)=>(
                <ExerciseRow key={i} ex={ex} active={false} onSelect={()=>setCur(i)}/>
              ))}
            </div>
      ):(
        /* ── SINGLE EXERCISE VIEW ── */
        <div style={{display:'flex',flexDirection:'column',flex:1}}>
          <div style={{padding:'12px 16px 10px'}}>
            <div style={{color:MUT,font:"500 10px/1 'DM Sans'",letterSpacing:'.14em',textTransform:'uppercase',marginBottom:5}}>{ex.cat}</div>
            <div style={{font:"700 24px/1 'DM Sans'",color:TXT,letterSpacing:'-.02em'}}>{ex.name}</div>
          </div>
          <div style={{padding:'0 16px',display:'flex',flexDirection:'column',gap:10,flex:1}}>
            {ex.sets.map((s,i)=>(
              <SetCard key={i} idx={i} done={s.done} min={s.min} sec={s.sec}
                onMin={v=>updateSet(i,'min',v)} onSec={v=>updateSet(i,'sec',v)} onToggle={()=>toggleSet(i)}/>
            ))}
            <button onClick={addSet} style={{height:44,border:`1px dashed ${BD}`,borderRadius:8,background:'transparent',color:MUT,font:"500 13px/1 'DM Sans'",cursor:'pointer'}}>
              + Add Set
            </button>
          </div>
        </div>
      )}

      {/* BOTTOM */}
      <div style={{padding:'10px 16px 8px',borderTop:`1px solid ${BD}`,display:'flex',gap:8,flexShrink:0}}>
        <button onClick={()=>setPicking(true)} style={{height:48,flex:1,border:`1px solid ${BD}`,borderRadius:8,background:S1,color:TXT,font:"600 13px/1 'DM Sans'",cursor:'pointer',display:'flex',alignItems:'center',justifyContent:'center',gap:6}}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={ACC} strokeWidth="2.5" strokeLinecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          Add Exercise
        </button>
        <button style={{height:48,flex:2,background:ACC,color:'#000',border:'none',borderRadius:8,font:"700 14px/1 'DM Sans'",cursor:'pointer'}}>
          Finish Workout
        </button>
      </div>

      {/* EXERCISE PICKER */}
      {picking&&<ExercisePicker onAdd={addExercise} onClose={()=>setPicking(false)}/>}
    </div>
  );
}

const navBtn={display:'flex',alignItems:'center',gap:5,height:34,padding:'0 10px',border:`1px solid ${BD}`,borderRadius:8,background:S1,color:TXT,cursor:'pointer',font:"500 13px/1 'DM Sans'"};

Object.assign(window,{WorkoutScreen});
