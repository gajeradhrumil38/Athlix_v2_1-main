/* global React, ReactDOM */
const { useState } = React;

const ACCENT = '#C8FF00';
const BG = '#0a0a0a';
const SURF = '#141414';
const BORDER = '#2a2a2a';
const INPUT = '#1e1e1e';
const TXT = '#f0f0f0';
const MUTE = '#888';

const athlixStyles = {
  page: { minHeight: '100vh', background: BG, color: TXT, fontFamily: "'DM Sans', system-ui, sans-serif", WebkitFontSmoothing: 'antialiased' },
  shell: { maxWidth: 1120, margin: '0 auto', padding: '32px 28px 80px' },
  topbar: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 40 },
  wordmark: { font: "400 34px/1 'Victory Striker', 'Bebas Neue', sans-serif", color: ACCENT, letterSpacing: '0.02em' },
  nav: { display: 'flex', gap: 8 },
  navBtn: (on) => ({
    font: "500 13px/1 'DM Sans'",
    padding: '10px 14px',
    borderRadius: 8,
    color: on ? TXT : MUTE,
    background: on ? '#1a1a1a' : 'transparent',
    border: `1px solid ${on ? BORDER : 'transparent'}`,
    cursor: 'pointer',
  }),
  avatar: { width: 36, height: 36, borderRadius: 9999, background: ACCENT, color: '#000', font: "700 14px/36px 'DM Sans'", textAlign: 'center' },
  headerRow: { display: 'flex', alignItems: 'flex-end', gap: 28, marginBottom: 36, paddingBottom: 28, borderBottom: `1px solid ${BORDER}` },
  heroMark: { width: 112, height: 112, borderRadius: 20, background: '#0d0d0d', border: `1px solid ${BORDER}`, display: 'grid', placeItems: 'center', position: 'relative', overflow: 'hidden' },
  heroMarkBlob: { position: 'absolute', bottom: -40, right: -40, width: 100, height: 100, borderRadius: '50%', background: ACCENT, opacity: 0.18, filter: 'blur(30px)' },
  heroMarkLetter: { font: "400 60px/1 'Victory Striker', 'Bebas Neue'", color: ACCENT, position: 'relative' },
  heroName: { font: "600 32px/1.1 'DM Sans'", marginBottom: 8 },
  heroSub: { color: MUTE, font: "400 15px/1.5 'DM Sans'" },
  eyebrow: { font: "500 11px/1 'DM Sans'", textTransform: 'uppercase', letterSpacing: '0.18em', color: '#666', marginBottom: 8 },

  statGrid: { display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 12, marginBottom: 28 },
  stat: { background: SURF, border: `1px solid ${BORDER}`, borderRadius: 12, padding: '18px 20px', display: 'flex', flexDirection: 'column', gap: 6, position: 'relative', overflow: 'hidden' },
  statLabel: { color: MUTE, font: "500 12px/1 'DM Sans'", textTransform: 'uppercase', letterSpacing: '0.12em' },
  statValue: { font: "600 28px/1 'DM Sans'", color: TXT },
  statUnit: { font: "500 14px/1 'DM Sans'", color: MUTE, marginLeft: 4 },
  statBar: { height: 2, background: ACCENT, position: 'absolute', left: 0, bottom: 0 },

  twoCol: { display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 16 },
  card: { background: SURF, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 24 },
  cardHead: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20 },
  cardTitle: { font: "600 16px/1 'DM Sans'", color: TXT },
  cardLink: { font: "500 12px/1 'DM Sans'", color: ACCENT, cursor: 'pointer', textDecoration: 'none' },

  label: { font: "500 13px/1.3 'DM Sans'", color: MUTE, display: 'block', marginBottom: 6 },
  input: { width: '100%', height: 44, padding: '0 14px', background: INPUT, border: `1px solid ${BORDER}`, borderRadius: 8, color: TXT, font: "400 15px/1 'DM Sans'", outline: 'none' },
  fieldRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 14 },
  fieldFull: { marginBottom: 14 },

  primary: { height: 44, padding: '0 22px', background: ACCENT, color: '#000', border: 'none', borderRadius: 8, font: "600 14px/1 'DM Sans'", cursor: 'pointer' },
  ghost: { height: 44, padding: '0 18px', background: 'transparent', color: MUTE, border: `1px solid ${BORDER}`, borderRadius: 8, font: "500 14px/1 'DM Sans'", cursor: 'pointer' },

  pill: (on) => ({ display: 'inline-flex', alignItems: 'center', gap: 6, height: 36, padding: '0 16px', borderRadius: 9999, border: `1px solid ${on ? ACCENT : BORDER}`, background: on ? 'rgba(200,255,0,0.06)' : '#1a1a1a', color: on ? ACCENT : MUTE, font: "500 13px/1 'DM Sans'", cursor: 'pointer' }),

  row: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '16px 0', borderBottom: `1px solid ${BORDER}` },
  rowLast: { borderBottom: 'none' },
  rowLabel: { font: "500 14px/1.2 'DM Sans'", color: TXT },
  rowSub: { font: "400 12px/1.3 'DM Sans'", color: MUTE, marginTop: 3 },

  switchTrack: (on) => ({ width: 36, height: 20, borderRadius: 9999, background: on ? ACCENT : '#2a2a2a', position: 'relative', cursor: 'pointer', transition: '.15s ease' }),
  switchKnob: (on) => ({ width: 14, height: 14, borderRadius: 9999, background: on ? '#000' : '#f0f0f0', position: 'absolute', top: 3, left: on ? 19 : 3, transition: '.15s ease' }),

  sideCard: { background: SURF, border: `1px solid ${BORDER}`, borderRadius: 12, padding: 20, marginBottom: 12 },
  readiness: { display: 'grid', placeItems: 'center', position: 'relative', width: 160, height: 160, margin: '8px auto 12px' },
  readingVal: { font: "600 42px/1 'DM Sans'", color: TXT },
  readingTxt: { font: "500 12px/1 'DM Sans'", color: MUTE, marginTop: 4, textTransform: 'uppercase', letterSpacing: '0.12em' },
};

function Switch({ on, onToggle }) {
  return (
    <div style={athlixStyles.switchTrack(on)} onClick={onToggle}>
      <div style={athlixStyles.switchKnob(on)} />
    </div>
  );
}

function Stat({ label, value, unit, fill }) {
  return (
    <div style={athlixStyles.stat}>
      <span style={athlixStyles.statLabel}>{label}</span>
      <div>
        <span style={athlixStyles.statValue}>{value}</span>
        {unit && <span style={athlixStyles.statUnit}>{unit}</span>}
      </div>
      <div style={{ ...athlixStyles.statBar, width: `${fill}%` }} />
    </div>
  );
}

function ReadinessRing({ value = 78 }) {
  const r = 64, c = 2 * Math.PI * r;
  const off = c - (value / 100) * c;
  return (
    <div style={athlixStyles.readiness}>
      <svg width="160" height="160" style={{ transform: 'rotate(-90deg)' }}>
        <circle cx="80" cy="80" r={r} fill="none" stroke="#1e1e1e" strokeWidth="10" />
        <circle cx="80" cy="80" r={r} fill="none" stroke={ACCENT} strokeWidth="10" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={off} />
      </svg>
      <div style={{ position: 'absolute', textAlign: 'center' }}>
        <div style={athlixStyles.readingVal}>{value}</div>
        <div style={athlixStyles.readingTxt}>Readiness</div>
      </div>
    </div>
  );
}

function ProfilePage() {
  const [tab, setTab] = useState('profile');
  const [sport, setSport] = useState('strength');
  const [unit, setUnit] = useState('kg');
  const [dist, setDist] = useState('km');
  const [notif, setNotif] = useState({ workouts: true, recovery: true, weekly: false, marketing: false });
  const [name, setName] = useState('Jordan Bell');
  const [handle, setHandle] = useState('jordan.bell');
  const [email] = useState('jordan@athlix.com');

  const sports = [
    { id: 'running', icon: '🏃', label: 'Running' },
    { id: 'cycling', icon: '🚴', label: 'Cycling' },
    { id: 'strength', icon: '🏋️', label: 'Strength' },
    { id: 'swimming', icon: '🏊', label: 'Swimming' },
    { id: 'crossfit', icon: '⚡', label: 'CrossFit' },
  ];

  return (
    <div style={athlixStyles.page}>
      <div style={athlixStyles.shell}>
        {/* Top bar */}
        <div style={athlixStyles.topbar}>
          <div style={athlixStyles.wordmark}>ATHLIX</div>
          <div style={athlixStyles.nav}>
            {['Dashboard', 'Train', 'Recovery', 'Profile'].map((n) => (
              <div key={n} style={athlixStyles.navBtn(n === 'Profile')}>{n}</div>
            ))}
          </div>
          <div style={athlixStyles.avatar}>JB</div>
        </div>

        {/* Header */}
        <div style={athlixStyles.headerRow}>
          <div style={athlixStyles.heroMark}>
            <div style={athlixStyles.heroMarkBlob} />
            <div style={athlixStyles.heroMarkLetter}>JB</div>
          </div>
          <div style={{ flex: 1 }}>
            <div style={athlixStyles.eyebrow}>Athlete Profile</div>
            <div style={athlixStyles.heroName}>{name}</div>
            <div style={athlixStyles.heroSub}>@{handle} · Strength · Member since 2024 · 142 workouts logged</div>
          </div>
          <button style={athlixStyles.ghost}>Edit photo</button>
          <button style={athlixStyles.primary}>Save changes</button>
        </div>

        {/* Stats */}
        <div style={athlixStyles.statGrid}>
          <Stat label="This week" value="4" unit="sessions" fill={66} />
          <Stat label="Total volume" value="12,480" unit="kg" fill={82} />
          <Stat label="Streak" value="9" unit="days" fill={45} />
          <Stat label="PRs this month" value="3" fill={50} />
        </div>

        {/* Two column layout */}
        <div style={athlixStyles.twoCol}>
          <div>
            {/* Account */}
            <div style={athlixStyles.card}>
              <div style={athlixStyles.cardHead}>
                <div style={athlixStyles.cardTitle}>Account</div>
                <a style={athlixStyles.cardLink}>Manage</a>
              </div>
              <div style={athlixStyles.fieldRow}>
                <div>
                  <label style={athlixStyles.label}>Full name</label>
                  <input style={athlixStyles.input} value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div>
                  <label style={athlixStyles.label}>Username</label>
                  <input style={athlixStyles.input} value={handle} onChange={(e) => setHandle(e.target.value)} />
                </div>
              </div>
              <div style={athlixStyles.fieldFull}>
                <label style={athlixStyles.label}>Email</label>
                <input style={{ ...athlixStyles.input, color: MUTE }} value={email} readOnly />
              </div>
              <div style={athlixStyles.fieldRow}>
                <div>
                  <label style={athlixStyles.label}>Height</label>
                  <input style={athlixStyles.input} defaultValue="182 cm" />
                </div>
                <div>
                  <label style={athlixStyles.label}>Weight</label>
                  <input style={athlixStyles.input} defaultValue="78 kg" />
                </div>
              </div>
            </div>

            {/* Training preferences */}
            <div style={{ ...athlixStyles.card, marginTop: 16 }}>
              <div style={athlixStyles.cardHead}>
                <div style={athlixStyles.cardTitle}>Training preferences</div>
              </div>

              <div style={athlixStyles.label}>Primary sport</div>
              <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap', marginBottom: 22 }}>
                {sports.map((s) => (
                  <div key={s.id} style={athlixStyles.pill(sport === s.id)} onClick={() => setSport(s.id)}>
                    <span style={{ fontSize: 14 }}>{s.icon}</span>
                    <span>{s.label}</span>
                  </div>
                ))}
              </div>

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
                <div>
                  <div style={athlixStyles.label}>Weight units</div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {['kg', 'lbs'].map((u) => (
                      <div key={u} style={{ ...athlixStyles.pill(unit === u), textTransform: 'uppercase', justifyContent: 'center', flex: 1 }} onClick={() => setUnit(u)}>{u}</div>
                    ))}
                  </div>
                </div>
                <div>
                  <div style={athlixStyles.label}>Distance units</div>
                  <div style={{ display: 'flex', gap: 8 }}>
                    {['km', 'mi'].map((u) => (
                      <div key={u} style={{ ...athlixStyles.pill(dist === u), textTransform: 'uppercase', justifyContent: 'center', flex: 1 }} onClick={() => setDist(u)}>{u}</div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Notifications */}
            <div style={{ ...athlixStyles.card, marginTop: 16 }}>
              <div style={athlixStyles.cardHead}>
                <div style={athlixStyles.cardTitle}>Notifications</div>
              </div>
              {[
                { key: 'workouts', label: 'Workout reminders', sub: 'Nudge me on my training days' },
                { key: 'recovery', label: 'Recovery alerts', sub: 'Ping me when readiness drops below 50' },
                { key: 'weekly', label: 'Weekly performance recap', sub: 'Every Sunday at 6pm' },
                { key: 'marketing', label: 'Product updates', sub: 'New features and tips' },
              ].map((n, i, arr) => (
                <div key={n.key} style={{ ...athlixStyles.row, ...(i === arr.length - 1 ? athlixStyles.rowLast : {}) }}>
                  <div>
                    <div style={athlixStyles.rowLabel}>{n.label}</div>
                    <div style={athlixStyles.rowSub}>{n.sub}</div>
                  </div>
                  <Switch on={notif[n.key]} onToggle={() => setNotif((p) => ({ ...p, [n.key]: !p[n.key] }))} />
                </div>
              ))}
            </div>
          </div>

          {/* Right rail */}
          <div>
            <div style={athlixStyles.sideCard}>
              <div style={athlixStyles.eyebrow}>Today</div>
              <ReadinessRing value={78} />
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginTop: 8 }}>
                <div>
                  <div style={{ ...athlixStyles.statLabel, fontSize: 11 }}>Sleep</div>
                  <div style={{ font: "600 18px/1 'DM Sans'" }}>7h 24m</div>
                </div>
                <div>
                  <div style={{ ...athlixStyles.statLabel, fontSize: 11 }}>HRV</div>
                  <div style={{ font: "600 18px/1 'DM Sans'" }}>64 ms</div>
                </div>
              </div>
            </div>

            <div style={athlixStyles.sideCard}>
              <div style={athlixStyles.cardHead}>
                <div style={athlixStyles.cardTitle}>Connected devices</div>
              </div>
              {[
                { name: 'Apple Watch', sub: 'Synced 2m ago', on: true },
                { name: 'Garmin Connect', sub: 'Not connected', on: false },
                { name: 'Strava', sub: 'Synced 1h ago', on: true },
              ].map((d, i, arr) => (
                <div key={d.name} style={{ ...athlixStyles.row, ...(i === arr.length - 1 ? athlixStyles.rowLast : {}) }}>
                  <div>
                    <div style={athlixStyles.rowLabel}>{d.name}</div>
                    <div style={athlixStyles.rowSub}>{d.sub}</div>
                  </div>
                  <Switch on={d.on} onToggle={() => {}} />
                </div>
              ))}
            </div>

            <div style={{ ...athlixStyles.sideCard, borderColor: 'rgba(255,77,77,0.25)' }}>
              <div style={{ ...athlixStyles.cardTitle, color: '#ff8080', marginBottom: 8 }}>Danger zone</div>
              <div style={athlixStyles.rowSub}>Permanently delete your account and all data.</div>
              <button style={{ ...athlixStyles.ghost, marginTop: 12, color: '#ff8080', borderColor: 'rgba(255,77,77,0.3)' }}>Delete account</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<ProfilePage />);
